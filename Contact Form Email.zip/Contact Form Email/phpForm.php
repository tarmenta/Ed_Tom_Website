<?php

/* Subject and email Variables */

	$emailSubject = 'Crazy PHP Scripting!';
	$webMaster = 'eduardojrz72@gmail.com'
	
/* Gathering Data Variables */

	$nameField = $_POST['name']
	$lastNameField = $_POST['lastName'] /* lastName is the name of the last name field in the html form */
	$emailField = $_POST['email'] /*email is the name of the email field in the html form*/
	$PhoneField = $_POST['phone']
	$messageField = $_POST['message']
	
	/*Make sure there are no spaces after EOD command, the code will not work if there is sapces.*/
	/*The email will contain everything in between the EOD command.*/
	$body = <<<EOD
<br><hr><br>
Email: $email <br>
Name: $name <br>
Phone Number: $phone <br>
Message: $message <br>
EOD;

	/*From will show the email address of the sender in the email*/
	$headers = "From: $email\r\n";
	/*This next line makes the body to be read as html*/
	$headers .= "Content-type: text/htm\r\n";
	$sucess = mail($webMaster, $emailSubject, $body, $headers);
	
/* Results render as HTTML */

	$theResults = <<<EOD
Great!
EOD;
echo "$theResults";

?>